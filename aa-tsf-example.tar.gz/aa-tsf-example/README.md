tsf install
